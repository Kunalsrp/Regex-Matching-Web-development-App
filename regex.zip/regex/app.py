from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/match', methods=['POST'])
def match():
    pattern = request.form['pattern']
    text = request.form['text']
    matches = re.findall(pattern, text)
    return render_template('matches.html', matches=matches)

@app.route('/validate-email', methods=['POST'])
def validate_email():
    email = request.form['email']
    is_valid = re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email)
    if is_valid:
        return 'Valid Email'
    else:
        return 'Invalid Email'

if __name__ == '__main__':
    app.run(debug=True)
